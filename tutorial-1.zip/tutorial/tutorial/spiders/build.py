import os
import sys
import scrapy
import datetime
from tutorial.items import TutorialItem


data={}
class BuildSpider(scrapy.Spider):

    name = "build"
    date = ""
    filename=""
    def __init__(self, category=None, *args, **kwargs):
        super(BuildSpider, self).__init__(*args, **kwargs)
        date = kwargs.get("date")
        filename = kwargs.get("filename")
        


    def start_requests(self):
        start_url = "http://www.bjjs.gov.cn/eportal/ui?pageId=308891"
        data['filter_LIKE_SGXKZH']='建字'   
        yield scrapy.FormRequest(start_url,formdata=data,method="POST",callback=self.parse) 

    def parse(self,response): 
        for sel in response.selector.xpath("//td[@class='format_time']"):           
            sel_date_info = sel.xpath("./text()").extract()[0]
            index = sel_date_info.rfind("-")
            sel_date = sel_date_info[0:index]
           
            if(sel_date == self.date):
                look_url = "http://www.bjjs.gov.cn" + str(sel.xpath("following-sibling::td[1]/a/@href").extract()[0])
                name = sel.xpath("preceding-sibling::td[3]/text()").extract();
                yield scrapy.Request(look_url,method="GET",callback=self.parse_detail,meta={'name':name}) 
            if(sel_date < self.date or self.date==""):
                return
  
        next_page_info = response.selector.xpath("//a[@class='pagingNormal'][3]/@onclick").extract()
        b_next_page = str(next_page_info).find("=")
        l_next_page = str(next_page_info).find(";")
        next_page = str(next_page_info)[b_next_page+1:l_next_page]
        data['currentPage'] = next_page
        yield scrapy.FormRequest(response.url,formdata=data,method="POST",callback=self.parse) 


    def parse_detail(self,response):
        info = response.selector.xpath("//td[@class='label']/following-sibling::td[1]/text()").extract()
        if(len(info) > 0):
            item = TutorialItem()
            print(response.url,info)
            item['pn'] = info[0].replace("\n", "").strip()
            item['pa'] = info[1].replace("\n", "").strip()
            item['county'] = info[2].replace("\n", "").strip()
            item['b_com'] = info[3].replace("\n", "").strip()
            item['area'] = info[4].replace("\n", "").strip()
            item['date'] = info[5].replace("\n", "").strip()
            item['addr'] = info[6].replace("\n", "").strip()
            item['m_com'] = info[7].replace("\n", "").strip()  
        else :
            item = TutorialItem()
            item['pn'] = u"该条信息没有被获取，项目名称："+ response.meta['name'][0] +",详细信息请查看："+ response.url
            item['pa'] = ""
            item['county'] =""
            item['b_com'] = ""
            item['area'] = ""
            item['date'] = ""
            item['addr'] =""
            item['m_com'] = ""
        yield item


       

